<?php
include("header.html");

?>

<h2>Registro pedidos - consultar</h2>


<?php
include("footer.html");

?>

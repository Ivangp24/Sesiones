<?php
include("header.html");

?>

<h2>Actualizar pedidos - consultar</h2>


<?php
include("footer.html");

?>
